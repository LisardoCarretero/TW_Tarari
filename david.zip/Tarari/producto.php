<!DOCTYPE html>        <!-- control shift v previsualización -->
<html lang="es" dir="ltr">
    <head>
        <meta charset="utf-8"><title>Página principal</title>
        <link rel="stylesheet" href="index.css">
        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    </head>
   
   
    <body>
        <?php include("cabecera.php");
        include_once('Forms/scripts/conexion.php');
        $id=$_GET['id'];
         $string = "SELECT * FROM producto WHERE idProducto = '$id'";
         $consulta=$mysqli->query($string);
         $producto= mysqli_fetch_array($consulta);

         
        ?>

        
        
        <div class="funcionadmin-list" id="pagina_producto">
            <div class="product_image">
                
                    <div class="caja_imagen" id="caja_producto">
                    <?php
                        echo('<img src="../../Images/Productos/'.$producto['Imagen'].'">');
                    ?>    
                    </div>
                </a>
            </div>
            <div class="product-box" id="nombre_descripcion">
                
                    <div class="product" id="caja_producto">
                    <?php
                        echo('<p class="NombreProducto" id="nombre_precio"> '.$producto['Nombre'].'</p> <p class="NombreProducto"> '.$producto['Descripcion'].'</p>');
                    ?>  
                        
                    </div>
                </a>
            </div>
            
            
            <div class="product-box" id="precio">
                <div class="product" id="caja_producto">
                    <?php
                        echo('<p class="NombreProducto" id="nombre_precio"> Precio '.$producto['Precio'].' €</p>' );
                    ?>   
                    
                    
                    <button class="AñadirCesta"> Añadir a la cesta </button>
                </div>
                
            </div>

        </div>

        <br></br>
        <br></br>    
            
        
        

        <footer class="footer">
            <label class="tittle_footer">Información de contacto</label>
            <p>950230404</p>
            <p>tarariktevi265@hotmail.com</p>
            <div class="social_media">
                <a href="https://www.facebook.com/regalostarariktevi" target="_blank"> <img class="button"
                        src="Icons/facebook.png"> </a>
                <a href="" target="_blank"> <img class="button" src="Icons/twitter.png"> </a>
                <a href="https://www.instagram.com/tarari_ke_te_vi/" target="_blank"> <img class="button"
                        src="Icons/insta.png"> </a>
                <a href="https://cutt.ly/ThINXzJ" target="_blank"> <img class="button" src="Icons/maps.png"> </a>
            </div>
        </footer>
        <script src="js/buscar_producto.js"></script>
    </body>
</html>