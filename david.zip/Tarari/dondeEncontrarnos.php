<!DOCTYPE html>        <!-- control shift v previsualización -->
<html lang="es" dir="ltr">
    <head>
        <meta charset="utf-8"><title>Dónde encontranos</title>
        <link rel="stylesheet" href="index.css">
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    </head>

    <?php include("cabecera.php");?>
        <div class="container_text">
            <span>¿Dónde nos encontramos? </span>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3193.11869905136!2d-2.465933884708969!3d36.839633179940485!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd707601bde38b61%3A0xfd25aafbf65b003e!2sTarari%20Ke%20Te%20VI!5e0!3m2!1ses!2ses!4v1608034407870!5m2!1ses!2ses" class="map" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

            <p>Paseo de Almería 24</p> 
            <p>04001 Almería</p> 

        </div>
        <footer class="footer">         
            <label class="tittle_footer">Información de contacto</label>         
            <p>950230404</p>        
            <p>tarariktevi265@hotmail.com</p>          
            <div class="social_media">             
                <a href="https://www.facebook.com/regalostarariktevi" target="_blank">  <img class="button" src="Icons/facebook.png"> </a>              
                <a href =""                                           target="_blank">  <img class="button" src="Icons/twitter.png" > </a>               
                <a href ="https://www.instagram.com/tarari_ke_te_vi/" target="_blank">  <img class="button" src="Icons/insta.png"   > </a>               
                <a href ="https://cutt.ly/ThINXzJ"                    target="_blank">  <img class="button" src="Icons/maps.png"    > </a>         
            </div>     
        </footer>
        <script src="js/buscar_producto.js"></script>
   </body>
</html>