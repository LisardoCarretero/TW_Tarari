<!DOCTYPE html> <!-- control shift v previsualización -->
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>formulario de Contacto</title>
    <link rel="stylesheet" href="Forms/estilos/login.css">
    <link rel="stylesheet" href="index.css">
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<?php include("cabecera.php");?>

    <div class="container">
        <div class="recuadro-contacto">
            
                <div class="row">
                    <div class="col-md-12">
                        <div class="well well-sm">
                            <form action="Forms/scripts/formularioContacto.php" class="form-horizontal" method="POST">
                               
                                    <legend class="contact_header">Formulario de contacto</legend>

                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-2 text-center"></span>
                                        <div class="col-md-8">
                                            <input id="name" name="nombre" type="text" placeholder="Nombre*"
                                                class="form-control">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-2 text-center" id></span>
                                        <div class="col-md-8">
                                            <input id="email" name="email" type="email"
                                                placeholder="Correo electrónico*" class="form-control">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-2 text-center"></span>
                                        <div class="col-md-8">
                                            <input required id="asunto" name="asunto" type="text" placeholder="Asunto*"
                                                class="form-control">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-2 text-center"></span>
                                        <div class="col-md-8">
                                            <textarea class="form-control" id="msg" name="msg" placeholder="Mensaje..."
                                                rows="7"></textarea>
                                        </div>
                                    </div>
                                    <input class="Fbuttons" type="submit" name="enviar" value="Enviar">
                                

                            </form>
                        </div>
                    </div>
                </div>
            
        </div>
    </div>
    <footer class="footer">
        <label class="tittle_footer">Información de contacto</label>
        <p>950230404</p>
        <p>tarariktevi265@hotmail.com</p>
        <div class="social_media">
            <a href="https://www.facebook.com/regalostarariktevi" target="_blank"> <img class="button"
                    src="Icons/facebook.png"> </a>
            <a href="" target="_blank"> <img class="button" src="Icons/twitter.png"> </a>
            <a href="https://www.instagram.com/tarari_ke_te_vi/" target="_blank"> <img class="button"
                    src="Icons/insta.png"> </a>
            <a href="https://cutt.ly/ThINXzJ" target="_blank"> <img class="button" src="Icons/maps.png"> </a>
        </div>
    </footer>
    <script src="js/buscar_producto.js"></script>
</body>

</html>