
$(document).ready(function(){
    $("#idBusqueda").keyup(function(e){
        if(e.keyCode==13){
            buscar_producto();
        }
    });
});


function buscar_producto () {
    window.location.href="resultadoBusqueda.php?text="+$("#idBusqueda").val();
}