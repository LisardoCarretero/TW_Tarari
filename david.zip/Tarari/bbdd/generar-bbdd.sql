-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema tarari
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `tarari` ;

-- -----------------------------------------------------
-- Schema tarari
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `tarari` DEFAULT CHARACTER SET utf8 ;
USE `tarari` ;

-- -----------------------------------------------------
-- Table `tarari`.`Categoria`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tarari`.`Categoria` ;

CREATE TABLE IF NOT EXISTS `tarari`.`Categoria` (
  `idCategoria` INT NOT NULL AUTO_INCREMENT,
  `Nombre` VARCHAR(45) NOT NULL,
  `Imagen` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idCategoria`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tarari`.`Oferta`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tarari`.`Oferta` ;

CREATE TABLE IF NOT EXISTS `tarari`.`Oferta` (
  `idOferta` INT NOT NULL AUTO_INCREMENT,
  `Descuento` INT NULL,
  PRIMARY KEY (`idOferta`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tarari`.`Producto`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tarari`.`Producto` ;

CREATE TABLE IF NOT EXISTS `tarari`.`Producto` (
  `idProducto` INT NOT NULL AUTO_INCREMENT,
  `Nombre` VARCHAR(45) NOT NULL,
  `Descripcion` VARCHAR(45) NOT NULL,
  `Precio` DOUBLE NOT NULL,
  `Stock` INT NOT NULL,
  `Imagen` VARCHAR(45) NOT NULL,
  `Flash` TINYINT NULL,
  `idCategoria` INT NOT NULL,
  `idOferta` INT NOT NULL,
  PRIMARY KEY (`idProducto`),
  INDEX `fk_Producto_Categoria_idx` (`idCategoria` ASC) ,
  INDEX `fk_Producto_Oferta1_idx` (`idOferta` ASC) ,
  CONSTRAINT `fk_Producto_Categoria`
    FOREIGN KEY (`idCategoria`)
    REFERENCES `tarari`.`Categoria` (`idCategoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Producto_Oferta1`
    FOREIGN KEY (`idOferta`)
    REFERENCES `tarari`.`Oferta` (`idOferta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tarari`.`Usuario`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tarari`.`Usuario` ;

CREATE TABLE IF NOT EXISTS `tarari`.`Usuario` (
  `idUsuario` INT NOT NULL AUTO_INCREMENT,
  `Nombre` VARCHAR(45) NULL,
  `Apellidos` VARCHAR(45) NULL,
  `Correo` VARCHAR(45) NULL,
  `Contrasena` VARCHAR(45) NULL,
  `Usuario` VARCHAR(45) NULL,
  `Telefono` VARCHAR(9) NULL,
  `Tipo` TINYINT NULL,
  PRIMARY KEY (`idUsuario`),
  UNIQUE INDEX `Usuario_UNIQUE` (`Usuario` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tarari`.`Carrito`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tarari`.`Carrito` ;

CREATE TABLE IF NOT EXISTS `tarari`.`Carrito` (
  `idCarrito` INT NOT NULL,
  `Envio` TINYINT NULL,
  `Confirmacion` TINYINT NULL,
  `idUsuario` INT NOT NULL,
  PRIMARY KEY (`idCarrito`),
  INDEX `fk_Carrito_Usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_Carrito_Usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `tarari`.`Usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tarari`.`Productos_carrito`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tarari`.`Productos_carrito` ;

CREATE TABLE IF NOT EXISTS `tarari`.`Productos_carrito` (
  `n_producto` INT NULL,
  `idCarrito` INT NOT NULL,
  `idProducto` INT NOT NULL,
  INDEX `fk_Productos_carrito_Carrito1_idx` (`idCarrito` ASC) ,
  INDEX `fk_Productos_carrito_Producto1_idx` (`idProducto` ASC) ,
  PRIMARY KEY (`idProducto`, `idCarrito`),
  CONSTRAINT `fk_Productos_carrito_Carrito1`
    FOREIGN KEY (`idCarrito`)
    REFERENCES `tarari`.`Carrito` (`idCarrito`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Productos_carrito_Producto1`
    FOREIGN KEY (`idProducto`)
    REFERENCES `tarari`.`Producto` (`idProducto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
