<html lang="es">
<head>
    
<head>
    <meta charset="utf-8">
    <title>Página principal</title>
    <link rel="stylesheet" href="Forms/estilos/login.css">
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>


<?php include("cabecera.php");?>


    <div class="container">
        <div class="recuadro">
            <img class="icon_user" src="Icons/icon_user2.png" alt="El icono de Usuario">
            <p>
                <form action="Forms/scripts/script-login.php" method="post">
                    <h5>
                        <p class="inicio-sesion">Iniciar sesión</p>
                    </h5>
                    <div class="form-group row">
                        <label for="inputUser" class="col-sm-2 col-form-label">
                            <p class="define_box" name="user">Usuario</p>
                        </label>
                        <div class="col-sm-9">
                            <input required id="login-input" type="text_box" name="user" class="form-control w-75">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword" class="col-sm-2 col-form-label" name="password">
                            <p class="define_box">Contraseña</p>
                        </label>
                        <div class="col-sm-9">
                            <input required id="login-input" type="password" name="password" class="form-control w-75">
                        </div>
                    </div>
                    <p class="text"><a href="algo de php" class="enlace">¿Has olvidado tu contraseña?</p></a>
                    <input class="buttons" type="submit" name="Inicio de sesión" value="Iniciar sesión">
                </form>
                <a href="registro.php"><button class="buttons3" type="submit" name="Registro"
                        value="Regístrate">Regístrate</button> </a>
            </p>
        </div>
    </div>
    <script src="js/buscar_producto.js"></script>
</body>

</html>
