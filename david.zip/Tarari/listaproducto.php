<!DOCTYPE html>        <!-- control shift v previsualización -->
<html lang="es" dir="ltr">
    <head>
        <meta charset="utf-8"><title>Página principal</title>
        <link rel="stylesheet" href="../index.css">
        <link rel="stylesheet" href="Estilos/estilos.css">
        <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>

        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    </head>
   
   
    <body>
        <nav class="navbar navbar-expand-lg navbar-light" id="cabecera">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <a href="../index.php"> <img class="icon_shop" src="../Icons/TARARI.png" width=15% height=15%
                            id="icon_shop"></a>
                    <span id="titulo"> TARARI KE TE VI </span>
                   
                   
                    <div class="search-place">
                        <input type="text" placeholder="Realizar una busqueda..." id="idBusqueda">
                        <img class="btn-main"><i class="fa fa-search" aria-hidden="true"></i></img>
                    </div>
    
                </div>
                <a href=""> <img class="icon_rigth" src="../Icons/cesta.png" width=45px height=45px id="icon_cesta"></a>
                <a href="../login.php"> <img class="button" src="../Icons/icon_user.png" id="icon_user"></a>
    
            </div>
        </nav>
        <div class="cabecera2">
        <a href="Producto/TODASLASCATEGORIAS.php" value="Regístrate" id="text_header" class="text-dark ">
            <p>Todas las categorías</p></a>
        <a href="C:\xampp\htdocs\Tw_Tarari\Ofertas" value="Ofertas" id="text_header" class="text-dark"> <p>Ofertas</p></a>
        <a href="../dondeEncontrarnos.php" value="location" id="text_header" class="text-dark"> <p>¿Dónde encontrarnos?</p></a>
        <a href="../contacto.php" value="Contáctanos" id="text_header" class="text-dark"> <p>Contáctanos</p></a>
    </div>
        
        
        <br></br>

        <table  class="ListaCategorias" >
            <tr>
                <td >
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td> 
            
                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td> 
            
                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td>

                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td>
            </tr>
           
            <tr>
                
                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td>
            
                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td> 
            
                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                        </div>
                        <table class="Cesta">
                            
                            <td>
                                <p class="producto">
                                Producto<br>Precio €
                                </p>
                            </td>
                            <td>
                                <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                            </td>
                        </table>
                </td>
                <td>
                    <div class="Categoria">
                        <a title="Producto" href="producto.html"><img src="../Icons/Ejemplo.jpg" alt="Cargando imagen..."></a>
                    </div>
                    <table class="Cesta">
                        
                        <td>
                            <p class="producto">
                            Producto<br>Precio €
                            </p>
                        </td>
                        <td>
                            <img id="cesta" src="../Icons/cesta_add.png" alt="Cargando imagen..." >
                        </td>
                    </table>
                
                    
                    
                </td>

        </tr>
        </table>

        <br></br>
        
            
            
        
        
        <footer class="footer">
            <label class="tittle_footer">Información de contacto</label>
            <p>950230404</p>
            <p>tarariktevi265@hotmail.com</p>
            <div class="social_media">
                <a href="https://www.facebook.com/regalostarariktevi" target="_blank"> <img class="button"
                        src="../Icons/facebook.png"> </a>
                <a href="" target="_blank"> <img class="button" src="../Icons/twitter.png"> </a>
                <a href="https://www.instagram.com/tarari_ke_te_vi/" target="_blank"> <img class="button"
                        src="../Icons/insta.png"> </a>
                <a href="https://cutt.ly/ThINXzJ" target="_blank"> <img class="button" src="../Icons/maps.png"> </a>
            </div>
        </footer>
        <script src="js/buscar_producto.js"></script>
    </body>
</html>