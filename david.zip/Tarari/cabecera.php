
<?php  session_start();?>


<body>

    <nav class="navbar navbar-expand-lg navbar-light" id="cabecera">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <a href="index.php"> <img class="icon_shop" src="Icons/TARARI.png" width=15% height=15%
                        id="icon_shop"></a>
                <span id="titulo"> TARARI KE TE VI </span>
               
               
                <div class="search-place">
                    <input type="text" placeholder="Realizar una busqueda..." id="idBusqueda">
                    <button class="btn-main" onclick="buscar_producto()"><i class="fa fa-search" aria-hidden="true"></i></button>
                </div>

            </div>
            <a href="cesta.php"> <img class="icon_rigth" src="Icons/cesta.png" width=45px height=45px id="icon_cesta"></a>
            
            <?php 
                $enlace="login.php";
                $boton="button"; 
                $iconos="Icons/icon_user.png"; 
                $fotoIcono="icon_user";
                $prueba="Forms/prueba.php";
                $logOut="Icons/logout.png";                         
                if (isset($_SESSION["usuario"])) {                 
                    echo("<a href=".$prueba."> <img class=".$boton." src=".$logOut." id=".$fotoIcono."></a>");
                } else { 
                    echo("<a href=".$enlace."> <img class=".$boton." src=".$iconos." id=".$fotoIcono."></a>");
                } 
            ?>

        </div>
    </nav>
    <div class="cabecera2">
        <a href="TODASLASCATEGORIAS.php" value="Regístrate" id="text_header" class="text-dark ">
            <p>Todas las categorías</p></a>
        <a href="C:\xampp\htdocs\Tw_Tarari\Ofertas" value="Ofertas" id="text_header" class="text-dark"> <p>Ofertas</p></a>
        <a href="dondeEncontrarnos.php" value="location" id="text_header" class="text-dark"> <p>¿Dónde encontrarnos?</p></a>
        <a href="contacto.php" value="Contáctanos" id="text_header" class="text-dark"> <p>Contáctanos</p></a>
    </div>
    