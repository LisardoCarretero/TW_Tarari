<?php
include_once("conexion.php");
$nombre = $_GET["nombre"];
$consulta = "DELETE FROM usuario where usuario.Nombre= '$nombre'";
$deleteUser = $mysqli->query($consulta);
echo "<center><h1>¡El usuario ".$nombre." ha sido borrado correctamente!</h1></center>";
header("Refresh:3; url=../../Admin/gestionarUsuarios.php");
