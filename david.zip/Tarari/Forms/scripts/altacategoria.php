<?php
    include_once('conexion.php');
    session_start();
    $nombre = $_POST['nuevaCat'];
    $image = $_FILES["foto"];
    
    $consultaSQL = "SELECT Nombre from categoria WHERE Nombre = '$nombre'";
    $consulta = $mysqli->query($consultaSQL);
    
    $resultado = mysqli_fetch_array($consulta);
    
    if(isset($resultado['nombre'])){
        echo "<center><h1>¡Categoría ya existente!</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
    } 
    else {
        if ($image['error'] == 0){
        $string = "../../../../Images/Categorias/";
        $rutaImagen = md5(date("Y-m-d H:i:s")) . ".jpeg";
        move_uploaded_file($image["tmp_name"], $string . $rutaImagen);
        $Insert = "INSERT INTO `categoria` (`idCategoria`, `Nombre`, `Imagen`) VALUES (NULL, '$nombre', '$rutaImagen');";
        $consulta_insert = $mysqli->query($Insert);

        echo "<center><h1>¡Categoría creada!</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
        }
        else{
            echo "<center><h1>¡Escoge una foto para la categoria!</h1></center>";
            header("Refresh:3; url=../../Admin/gestionarProductos.php");
        }
    }
