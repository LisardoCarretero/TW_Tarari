<?php
    include_once('conexion.php');
    session_start();
    $nombre = $_POST['delete'];
  
   if($nombre == "Selecciona el producto a eliminar"){
    echo "<center><h1>¡El producto seleccionado no es válido!</h1></center>";
    header("Refresh:3; url=../../Admin/gestionarProductos.php");
   }else{
    $consultaImg = "SELECT Imagen FROM producto WHERE idProducto = '$nombre'";
    $consultaDelete = "DELETE FROM producto WHERE idProducto = '$nombre'";
    $deletefoto = $mysqli->query($consultaImg);
    $deleteproducto =  $mysqli->query($consultaDelete);
    $ruta = "../../../../Images/Productos/";
    $culo = mysqli_fetch_array($deletefoto);
    
    unlink($ruta.$culo[0]);
    
    echo "<center><h1>¡El producto ".$nombre." ha sido borrado correctamente!</h1></center>";
    header("Refresh:3; url=../../Admin/gestionarProductos.php");
 }
   
?>