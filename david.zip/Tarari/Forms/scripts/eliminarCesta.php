<?php
session_start();
include_once('conexion.php');

$id = $_POST['idProducto'];

$sql = "DELETE FROM productos_carrito WHERE idProducto ='".$id."'";

$consulta = $mysqli->query($sql);




header("Refresh:0; url=../../cesta.php");

?>