<?php
    include_once('conexion.php');
    session_start();
    $nombre = $_POST['deleteCat'];
   
   if($nombre == "Selecciona la categoría a eliminar"){
    echo "<center><h1>¡Selecciona una categoría válida!</h1></center>";
    header("Refresh:3; url=../../Admin/gestionarProductos.php");

   }
   else{$consultaImg = "SELECT Imagen FROM categoria WHERE idCategoria = '$nombre'";
    $consultaDelete = "DELETE FROM categoria WHERE idCategoria = '$nombre'";
    $deletefoto = $mysqli->query($consultaImg);
    $deleteproducto =  $mysqli->query($consultaDelete);
    $ruta = "../../../../Images/Categorias/";
    $culo = mysqli_fetch_array($deletefoto);
    
    unlink($ruta.$culo[0]);
   
    echo "<center><h1>¡La categoría ".$nombre." ha sido borrada correctamente!</h1></center>";
    header("Refresh:3; url=../../Admin/gestionarProductos.php");
}
