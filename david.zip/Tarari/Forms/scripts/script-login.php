<?php
    session_start();
    include_once('conexion.php');
    $user = $_POST['user'];
    $password = $_POST['password'];
    $consultaSQL = "SELECT * from Usuario WHERE Usuario.Usuario = '$user'";
    $consulta = $mysqli->query($consultaSQL);
    
    $resultado = mysqli_fetch_array($consulta);

    if(isset($resultado['Usuario']) && $resultado['Contrasena'] == $password){
        $_SESSION["usuario"] = $user;
        $id = $resultado["idUsuario"];
        $_SESSION["id"] = $id;
        $tipo=$resultado['Tipo'];
        $_SESSION['tipo']=$tipo;

        if ($resultado['Tipo']==1) {
            header("Refresh:0; url=../../index.php");
        } else {
            header("Refresh:0; url=../../Admin/indexAdmin.php");
        }
        
    }
    else if(isset($resultado['Username'])){
        echo ("<center><h1>¡Fallo en contraseña!</h1></center>");
        
        header("Refresh:2; url=../../login.php");
    }else {
        echo ("<center><h1>¡Fallo en usuario!</h1></center>");
        header("Refresh:2; url=../../login.php");
    }
?>