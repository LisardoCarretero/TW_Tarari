<?php
    include_once('conexion.php');
    session_start();

    $Nombre = $_POST['nombre'];
    $Apellidos = $_POST['Apellidos'];
    $Email = $_POST['email'];
    $Conf_email = $_POST['emailBool'];
    $Password = $_POST['password'];
    $Conf_password = $_POST['passwordBool'];
    $Usuario = $_POST['Usuario'];
    $Telefono = $_POST['telf'];

    $findme   = '@';
    $pos = strpos($Email, $findme);
    if ($pos === false) {
        echo "<center><h1>¡Usuario ya registrado!</h1></center>";
        header("Refresh:0; url=../login.php"); 
    } 
    //Comprobar si confirmaciones son iguales, si no lanzar a una nueva pagina 
    $consultaSQL = "SELECT * from Usuario WHERE Usuario = '$Usuario' AND Contrasena = '$Password'";
    $consulta = $mysqli->query($consultaSQL);
    
    if($consulta->num_rows ==0){

        
        $Insert = "INSERT INTO Usuario (Usuario, Nombre, Apellidos, Correo, Contrasena, Telefono, Tipo)
        VALUES ('$Usuario', '$Nombre', '$Apellidos', '$Email', '$Password', '$Telefono', '1')";
        
        $consulta_insert = $mysqli->query($Insert);

        $nSQL = "INSERT INTO carrito (Envio, Confirmacion , idUsuario ) VALUES ('0', '0', (select idUsuario from usuario where Usuario = '$Usuario'))";
        $nConsulta = $mysqli->query($nSQL);

        
        header("Refresh:0; url=../../index.php");
    }else {
        echo "<center><h1>¡Usuario ya registrado!</h1></center>";
        header("Refresh:0; url=../login.php");       
    }
?>