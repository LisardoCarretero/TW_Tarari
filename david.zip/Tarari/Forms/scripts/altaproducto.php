<?php
include_once('conexion.php');
session_start();
$nombre = $_POST['nombreProducto'];

$consultaSQL = "SELECT Nombre from Producto WHERE Nombre = '$nombre'";
$consulta = $mysqli->query($consultaSQL);
$resultado = mysqli_fetch_array($consulta);

$image = $_FILES["foto"];


if (isset($resultado['nombre'])) {
    echo "<center><h1>¡Un producto con ese nombre, ya existe!</h1></center>";
    header("Refresh:3; url=../../Admin/gestionarProductos.php");
} else {
    $categoria = $_POST['categoria'];
    $ofertaFlash = $_POST["ofertaFlash"];
    $oferta = $_POST['oferta'];
    $stock = $_POST['stock'];
    if ($ofertaFlash != 0 && $ofertaFlash != 1) {
        echo "<center><h1>¡Error al introducir oferta flash!</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
    }
    if ($oferta == "Selecciona una oferta disponible") {
        echo "<center><h1>¡Oferta no válida !</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
    } elseif ($categoria == "Selecciona la categoria deseada") {
        echo "<center><h1>¡Escoge una categoria!</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
    } else if ($image['error'] == 0) {
        $string = "../../../../Images/Productos/";
        $rutaImagen = md5(date("Y-m-d H:i:s")) . ".jpeg";
        move_uploaded_file($image["tmp_name"], $string . $rutaImagen);
        
        $descripcion = $_POST['descripción'];
        $precio = $_POST['precio'];
        $Insert = "INSERT INTO Producto (Nombre, Descripcion, Imagen, Precio, idOferta, idCategoria, Flash, Stock)
                    VALUES ('$nombre','$descripcion','$rutaImagen','$precio','$oferta','$categoria','$ofertaFlash','$stock')";
        $consulta_insert = $mysqli->query($Insert);
        echo "<center><h1>¡Alta de producto realizada!</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
    } else {
        echo "<center><h1>¡Escoge una foto para el producto!</h1></center>";
        header("Refresh:3; url=../../Admin/gestionarProductos.php");
    }
}
