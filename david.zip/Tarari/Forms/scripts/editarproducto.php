<?php
include_once("conexion.php");
$idProducto = $_POST["nombre"];
if ($idProducto == "Selecciona el producto a editar") {
    echo "<center><h1>¡El producto seleccionado no es válido!</h1></center>";
    header("Refresh:2; url=../../Admin/PestionarProducto.php");
} else {
    $editNombre = $_POST["editNombre"];
    $editDescripcion = $_POST["descripción"];
    $editPrecio = $_POST["precio"];
    $editStock = $_POST["stock"];
    $editOfertaFlash = $_POST["ofertaFlash"];
    $editOferta = $_POST["oferta"];
    $editCategoria = $_POST["categoria"];
    $image = $_FILES["foto"];

    if ($editNombre == "") { //Comprobar que el nombre no se envía vacío
        $consultaSQL = "SELECT Nombre from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $editNombreArray = mysqli_fetch_array($consulta);
        $editNombre = $editNombreArray[0];
    }
    if ($editDescripcion == "") { //Comprobar que la oferta no se envía vacía
        $consultaSQL = "SELECT Descripcion from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $editDescripcionArray = mysqli_fetch_array($consulta);
        $editDescripcion = $editDescripcionArray[0];
    }
    if ($editPrecio == "") { //Comprobar que la oferta no se envía vacía
        $consultaSQL = "SELECT Precio from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $editPrecioArray = mysqli_fetch_array($consulta);
        $editPrecio = $editPrecioArray[0];
    }
    if ($editStock == "") { //Comprobar que la oferta no se envía vacía
        $consultaSQL = "SELECT Stock from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $editStockArray = mysqli_fetch_array($consulta);
        $editStock = $editStockArray[0];
    }

    if ($editOferta == "No cambiar oferta") { //Comprobar que la oferta no se envía vacía
        $consultaSQL = "SELECT idOferta from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $editOfertaArray = mysqli_fetch_array($consulta);
        $editOferta = $editOfertaArray[0];
    }
    if ($editCategoria == "No cambiar categoria") { //Comprobar que la categoria no se envía vacía
        $consultaSQL = "SELECT idCategoria from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $editCategoriaArray = mysqli_fetch_array($consulta);
        $editCategoria = $editCategoriaArray[0];
    }

    if ($image['error'] == 0) {
        $consultaImg = "SELECT Imagen FROM producto WHERE idProducto = '$nombre'";
        $consultaDelete = "DELETE FROM producto WHERE idProducto = '$nombre'";
        $deletefoto = $mysqli->query($consultaImg);
        $ruta = "../../../../Images/Productos/";
        $culo = mysqli_fetch_array($deletefoto);

        unlink($ruta . $culo[0]);
        $string = "../../../../Images/Producto/";
        $rutaImagen = md5(date("Y-m-d H:i:s")) . ".jpeg";
        move_uploaded_file($image["tmp_name"], $string . $rutaImagen);
    } else {

        $consultaSQL = "SELECT Imagen from Producto WHERE idProducto = '$idProducto'";
        $consulta = $mysqli->query($consultaSQL);
        $rutaImagenArray = mysqli_fetch_array($consulta);
        $rutaImagen = $rutaImagenArray[0];
    }

    // Lanzamos el update para actualizar los datos
    $consultaUpdate = "UPDATE Producto SET Nombre='$editNombre', Descripcion='$editDescripcion', Precio='$editPrecio ', 
    Stock=' $editStock ', idOferta =' $editOferta ', idCategoria=' $editCategoria ', Stock = '$editStock', Imagen=' $rutaImagen ', Flash='$editOfertaFlash' WHERE idProducto= ' $idProducto' ";
    $consultaEdit = $mysqli->query($consultaUpdate);
    echo "<center><h1>¡El producto $editNombre se ha actulizado correctamente!</h1></center>";
    header("Refresh:2; url=../../Admin/gestionarProductos.php");
}
