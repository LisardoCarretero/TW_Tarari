<?php
include_once('conexion.php');

$response = new stdClass();
$datos = [];
$i=0;
$sql = "select * from producto where Flash = '1'";
$result = $mysqli->query($sql);
while($row=$result->fetch_array(MYSQLI_BOTH)){
    $obj = new stdClass();
    $obj->id = $row['idProducto'];
    $obj->nombre = $row['Nombre'];
    $obj->descripcion = $row['Descripcion'];
    $obj->imagen = $row['Imagen'];
    $obj->precio = $row['Precio'];
    
    $datos[$i] = $obj;
    $i++;
}
$response->datos=$datos;
header('content-Type: application/json');
echo json_encode($response);
?>