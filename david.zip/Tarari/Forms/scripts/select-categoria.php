<?php
include_once('conexion.php');

$response = new stdClass();
$datos = [];
$i=0;
$sql = "select * from categoria";
$result = $mysqli->query($sql);
while($row=$result->fetch_array(MYSQLI_BOTH)){
    $obj = new stdClass();
    $obj->nombre = $row['Nombre'];
    $obj->imagen = $row['Imagen'];
    
    $datos[$i] = $obj;
    $i++;
}
$response->datos=$datos;
header('content-Type: application/json');
echo json_encode($response);
?>