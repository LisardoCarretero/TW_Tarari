<?php 
session_start();
include_once('conexion.php');



$id = $_POST['idCesta'];
$sql = "UPDATE carrito SET Confirmacion = 1 WHERE carrito.idCarrito = '".$id."'";
$consulta = $mysqli->query($sql);

header("Refresh:2; url=../../cesta.php");

?>