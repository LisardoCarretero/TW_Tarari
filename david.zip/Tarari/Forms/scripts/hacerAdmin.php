<?php
include_once("conexion.php");
$nombre = $_GET["nombre"];
$consultaHacerAdmin = "UPDATE usuario SET Tipo = '0' WHERE Nombre ='$nombre'";
$admin = $mysqli->query($consultaHacerAdmin);

echo "<center><h1>¡Usuario administrador dado de alta!</h1></center>";
header("Refresh:1; url=../../Admin/gestionarUsuarios.php");