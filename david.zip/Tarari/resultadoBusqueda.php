<!DOCTYPE html> <!-- control shift v previsualización -->
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Formulario Registro</title>
    
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>


</head>
    <?php include("cabecera.php");?>

    <div id="cabecera-resultado"> Resultados de la busqueda para : <strong><?php echo $_GET['text'];?></strong></div>

    <div class="category-list" id="space-list">      
        
    <script type="text/javascript">
            var text = "<?php echo $_GET['text']; ?>";
            $(document).ready(function(){            
                $.ajax({
                    
                    url:'Forms/scripts/select-busqueda.php',
                    type: 'POST',
                    data:{
                        text:text
                    },
                    success:function(data){
                        console.log(data); 
                        let html ='';
                        for(var i = 0; i < data.datos.length; i++){
                            html+=
                            '<div class="product-box">'+
                                '<a href="producto.php?id='+data.datos[i].id+'">'+
                                    '<div class="product">'+
                                        
                                        '<img src=../../Images/Productos/'+  data.datos[i].imagen+  '>'+
                                        '<div class="titulo">'+data.datos[i].nombre+'</div>'+
                                        '<div class="descripcion">'+data.datos[i].descripcion+'</div>'+
                                        '<div class="precio">'+data.datos[i].precio+' €</div>'+
                                    '</div>'+
                                '</a>'+
                            '</div>';
                        }
                        console.log(html);
                        document.getElementById("space-list").innerHTML=html;
                    },
                    error:function(err){
                        console.error(err);
                    }
                });
            });
            
        </script>
    </div>
    
    <script src="js/buscar_producto.js"></script>
</body>
</html>