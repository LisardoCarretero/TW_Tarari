<!DOCTYPE html> <!-- control shift v previsualización -->
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Página principal</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>


    
    

<?php include("cabecera.php");


if (isset($_SESSION["usuario"])) {                 
    


?>

<div class="carrito"><h1>Carrito</h1>




<?php 
echo("<div class='cesta-div'>");    
echo('<img class="cesta-img" src="Icons/carrito.png">');
echo("</div>");

include_once("Forms/scripts/conexion.php");

$usuario = $_SESSION["id"];

$consultaSQL = "SELECT * from Carrito WHERE Carrito.IdUsuario = '$usuario'";

$consulta = $mysqli->query($consultaSQL);



$resultado = mysqli_fetch_array($consulta);

if ($resultado["Confirmacion"]==1) {
    
    $nSQL = "INSERT INTO carrito (Envio, Confirmacion , idUsuario ) VALUES ('0', '0', '$usuario')";
    $nConsulta = $mysqli->query($nSQL);
}

$id=$resultado["idCarrito"];

$sql="SELECT * from productos_carrito WHERE productos_carrito.idCarrito = '$id'";
$consulta2=$mysqli->query($sql);





$total=0;

while ($resultado2 = mysqli_fetch_array($consulta2)){

    //print_r($resultado2);

    $idP=$resultado2["idProducto"];

    $string= "SELECT * from Producto WHERE Producto.IdProducto = '$idP'";

    $myConsulta=$mysqli->query($string);

    $jaja= mysqli_fetch_array($myConsulta);

    

    echo("<div class='producto-cesta'>");

        echo("<form action='Forms/scripts/eliminarCesta.php' method='POST' enctype='multipart/form-data' class='form-inline'>");
            
            echo("<div class='img-container'>");    
                echo('<img class="cesta-img" src="../../Images/Productos/'.$jaja["Imagen"].'">');
            echo("</div>");
            
            echo('<input id="idProducto" name="idProducto" type="hidden" value="'.$idP.'">');
            echo("<p class='nombre-p-cesta'>Nombre del producto: <strong>".$jaja['Nombre'] ."</strong> </p>");
            echo("<p class='precio-p-cesta'> Precio por unidad : <strong>".$jaja['Precio']." € </strong></p>");
            echo("<p class='n-productos-cesta'> Cantidad : <strong>".$resultado2['n_producto']."</strong></p>");
            echo("<p class='total-p-cesta'> Total = <strong>".$jaja['Precio']*$resultado2['n_producto']."</strong> € </p>");
            $total+=$jaja['Precio']*$resultado2['n_producto'];

            echo('<button id="basura-cesta"> <image class="button" src="Icons/basura.png" id="josean"></button>');
        echo("</form>");

    echo("</div>");
    

}

//echo("<span>".$resultado2['n_producto']." SubTotal = ".$jaja['Precio']*$resultado2['n_producto']." unidades monetartias </span>");



echo('<div class="cesta">');
echo("<form action='Forms/scripts/confirmarCesta.php' method='POST' enctype='multipart/form-data' class='form-inline'>");
echo('<input id="idCesta" name="idCesta" type="hidden" value="'.$id.'">');
echo("<p class='precio-final' Total = ".$total." unidades de divisa legal </p>");
echo('<button type="button" id="confirmar-reserva" class="btn btn">Confirmar reserva</button>');
echo("</form>");
echo("</div>");

?>


</div>

<?php

} else {

    echo("<h1>Incia sesión primero</h1><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>");

    header("Refresh:10000; url=index.php");
}

?>

<footer class="footer">         
            <label class="tittle_footer">Información de contacto</label>         
            <p>950230404</p>        
            <p>tarariktevi265@hotmail.com</p>          
            <div class="social_media">             
                <a href="https://www.facebook.com/regalostarariktevi" target="_blank">  <img class="button" src="Icons/facebook.png"> </a>              
                <a href =""                                           target="_blank">  <img class="button" src="Icons/twitter.png" > </a>               
                <a href ="https://www.instagram.com/tarari_ke_te_vi/" target="_blank">  <img class="button" src="Icons/insta.png"   > </a>               
                <a href ="https://cutt.ly/ThINXzJ"                    target="_blank">  <img class="button" src="Icons/maps.png"    > </a>         
            </div>     
        </footer>
        <script src="js/buscar_producto.js"></script>
</body>

</html>