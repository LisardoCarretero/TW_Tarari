<!DOCTYPE html>        <!-- control shift v previsualización -->
<html lang="es" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Página principal</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>


    
    
<?php include("cabecera.php");?>
   
        <div class="category-list" id="space-list">      
        
            <script type="text/javascript">
            $(document).ready(function(){            
                $.ajax({
                    url:'Forms/scripts/select-categoria.php',
                    type: 'POST',
                    data:{},
                    success:function(data){
                        console.log(data); 
                        let html ='';
                        for(var i = 0; i < data.datos.length; i++){
                            html+=
                            '<div class="product-box">'+
                                '<a href="">'+
                                    '<div class="product">'+
                                        
                                        '<img src=../../Images/Categorias/'+  data.datos[i].imagen+'>'+
                                        '<div class="titulo" id="nombre_categoria">'+data.datos[i].nombre+'</div>'+
                                    '</div>'+
                                '</a>'+
                            '</div>';
                        }
                        console.log(html);
                        document.getElementById("space-list").innerHTML=html;
                    },
                    error:function(err){
                        console.error(err);
                    }
                });
            });
            
            </script>
        </div>
        
        <br></br>
        <br></br>            
        <br></br>
        <br></br> 
        
        

        <footer class="footer">         
            <label class="tittle_footer">Información de contacto</label>         
            <p>950230404</p>        
            <p>tarariktevi265@hotmail.com</p>          
            <div class="social_media">             
                <a href="https://www.facebook.com/regalostarariktevi" target="_blank">  <img class="button" src="Icons/facebook.png"> </a>              
                <a href =""                                           target="_blank">  <img class="button" src="Icons/twitter.png" > </a>               
                <a href ="https://www.instagram.com/tarari_ke_te_vi/" target="_blank">  <img class="button" src="Icons/insta.png"   > </a>               
                <a href ="https://cutt.ly/ThINXzJ"                    target="_blank">  <img class="button" src="Icons/maps.png"    > </a>         
            </div>     
        </footer>
        <script src="js/buscar_producto.js"></script>
    </body>    
</html>